const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightboxImage');
const images = document.querySelectorAll('.image-grid img');
let currentIndex = 0;

const intros = {
    'alex': {
        text: `Alex: The detail-oriented mastermind behind the organization and aesthetics of our gallery. Alex played a key role in ensuring that every image, layout, and interaction was meticulously planned and executed. His focus on creating a visually appealing and user-friendly interface helped transform our ideas into reality. His dedication to perfection elevated the entire project`
    },
    'kondi': {
        text: `Kondi: The technical genius who ensured everything worked flawlessly. Kondi is the one who handled all the coding challenges and made sure the gallery functioned as intended. With a keen eye for efficiency and performance, Kondi worked tirelessly behind the scenes to ensure the gallery was responsive, fast, and seamless. His technical expertise brought our creative ideas to life in a way that was both effective and smooth.`
    },
    'assanatu': {
        text: `Assanatu: Our team’s creative dynamo, Assanatu brought an infectious energy and an eye for dynamic design. As a girl with a flair for vibrant and bold ideas, she injected color and life into the gallery, making it more than just a collection of pictures but a lively visual experience. Her creative vision ensured that the gallery was not only functional but also full of personality. Her ability to think outside the box and introduce innovative concepts has been integral to the project’s success.`
    },
    'thomas': {
        text: `Thomas: A versatile and well-rounded team member, Thomas struck a perfect balance between design and functionality. Thomas’s innovative contributions to both the creative and technical aspects of the gallery helped bring harmony to the project. Whether it was enhancing the user interface or improving the user experience, Thomas’s ability to think strategically played a huge role in refining the gallery.`
    },
    'andrew': {
        text: `Andrew: The problem-solver who kept everything running smoothly. Andrew was focused on the finer details, making sure every element of the project was in place. From fixing bugs to optimizing performance, Andrew’s attention to detail ensured that the gallery was not only aesthetically pleasing but also worked perfectly across all devices. His dedication to ensuring the project came together seamlessly made him an invaluable member of the team.`
    }
};

images.forEach((img, index) => {
    img.addEventListener('click', () => {
        openLightbox(index);
    });
});

function showGallery() {
    document.querySelector('.front-page').style.display = 'none';
    document.querySelector('.gallery').style.display = 'flex';

    
    document.getElementById('galleryIntroText').style.display = 'block';
}

function filterImages(category) {
    images.forEach(img => {
        if (category === 'all' || img.dataset.category === category) {
            img.style.display = 'block';
        } else {
            img.style.display = 'none';
        }
    });

   
    if (category === 'all') {
        document.getElementById('galleryIntroText').style.display = 'block';
    } else {
     
        document.getElementById('galleryIntroText').style.display = 'none';
    }


    showIntro(category);
}

function showIntro(name) {
    const introContainer = document.getElementById("dynamicIntro");
    const introText = document.getElementById("introText");

    if (intros[name]) {  
        introText.textContent = intros[name].text;
        introText.style.display = "block";
        introContainer.style.display = "block";
    } else {
        introContainer.style.display = "none";
    }
}

function openLightbox(index) {
    currentIndex = index;
    lightbox.style.display = 'flex';
    lightboxImage.src = images[currentIndex].src;
}

function closeLightbox() {
    lightbox.style.display = 'none';
}

function plusSlides(n) {
    currentIndex += n;

    if (currentIndex < 0) {
        currentIndex = images.length - 1; 
    } else if (currentIndex >= images.length) {
        currentIndex = 0; 
    }

    lightboxImage.src = images[currentIndex].src;
}

function goToFrontPage() {
    document.querySelector('.gallery').style.display = 'none';
    document.querySelector('.front-page').style.display = 'flex';
}
